# Web_DIY
혼자서 웹 만들어보기 프로젝트

## Notion
📒 <a href="https://messenger-kh.notion.site/DIY_project_choi-4d9d779488864b35857c20e670adf570">DIY_project </a></br>
🍰 <a href="https://messenger-kh.notion.site/282afd346783482e827099747002b6c4?v=df90ce9a15df49fda04c30a96242b1eb">인프런_김영한</a>
